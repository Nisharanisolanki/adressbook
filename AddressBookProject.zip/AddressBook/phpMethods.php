<?php
    
    
    // $names = array(
        //     'Amir'=> array ('Banana', 'Apple', 'Grapes'),
        //     'Manoj'=> array ('Lime', 'Apple', 'Peach')
        // );
        
        // echo count($names);
        // echo sizeof($names);
        
        // echo sizeof($names, 1);
        
        
        // if(in_array(55,$names, true)){
            //     echo "Yes, Value Found";
            // }else{
                //     echo "Sorry, Value not Found";
                // }
                
    // $names= array('Amit', 'golu', 0=> 'Kamla', '55');
    $animals= ['a' => 'Cat', 'b'=> 'dog'];
    $fruits= ['Apple', 'Banana','Peach'];

    $newArray= array_replace($animals, $fruits);
    
    print_r($newArray);
?>