<!DOCTYPE html>
<?php
error_reporting(0);

include("connection.php");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
<form action="" method="post" enctype="multipart/form-data">
        <table border="0" align="center">
            <tr>
                <th colspan="2">Enter Details </th>
            </tr>
            <tr>
                <td>Roll</td>
                <td><input type="text" name="rollno" value="<?php echo $_GET['roll'];?>"></td>
            </tr>
            <tr>
                <td>Name</td>
                <td><input type="text" name="name" value="<?php echo $_GET['name'];?>"></td>
            </tr>
            <tr>
                <td>Course</td>
                <td><input type="text" name="course" value="<?php echo $_GET['course'];?>"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="file" name="image"></td>
            </tr>
            <tr>
                <td colspan="2" align="right"><input type="submit" name="submit"></td>
            </tr>
        </table>

    </form>
    
<?php
session_start();

$userprofile=$_SESSION['user_name'];

if($userprofile==null){
    header('location:login.php');
}
include("connection.php");

if(isset($_POST['submit'])){

    $id=$_GET['id'];
    $roll=$_POST['rollno'];
    $name=$_POST['name'];
    $course=$_POST['course'];
    
    $filename=$_FILES['image']['name'];
    $tempname=$_FILES['image']['tmp_name'];


    // $fileExt= explode('.', $filename);
    // print_r($fileExt);

    $folder="Images/".$filename;
    move_uploaded_file($tempname, $folder);

    $query= "UPDATE stu_details SET ROLL='$roll',IMGLINK='$folder', NAME='$name', COURSE='$course', USERNAME='$userprofile', PASSWORD='' WHERE ID='$id'";
    $data= mysqli_query($conn, $query);

    if($data){
        echo "Record updated successfully <a href='fetch.php'>View All</a>";
    }
    else{
        echo "Failed to update record";
    }
}
else{
    echo "<font color='blue'>Click update to save applied changes</font>";
}
?>
</body>
</html>