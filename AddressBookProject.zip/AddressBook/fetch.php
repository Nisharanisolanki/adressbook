<style>
    td{
        padding: 5px;
        text-align: center;
    }

ul {
  list-style-type: none;
}

li {
  float: left;
}
li a {
padding: 10px;
}
.active{
    background-color: black;
    padding: 3px;
}
.active a{
    color:white;
    text-decoration: none;
}
</style>

<?php
include("connection.php");
$limit=2;

if(isset($_GET['page'])){
    $page=$_GET['page'];
}
else{
    $page=1;
}

$offset=($page-1)*$limit;

session_start();
error_reporting(0);
$userprofile=$_SESSION['user_name'];
echo "<h3 align='right' style='background-color:black; color:white; display: inline; padding: 5px;'>"."Welcome ". $_SESSION['user_name']."</h3><br>";

if($userprofile==null){
    header('location:login.php');
}

$query= "SELECT * FROM stu_details WHERE username='$userprofile' ORDER BY roll ASC LIMIT {$offset},{$limit}";
$data= mysqli_query($conn, $query);
$total= mysqli_num_rows($data);

$search=$_GET['search'];
$s_query="SELECT * FROM stu_details WHERE name='$search'";
$s_data= mysqli_query($conn, $s_query);

echo "<h3 align='right' style='background-color:yellow; color:black; display: inline; padding:3px;'>Saved Contact: ". $total. "</h3><br>";
if($total!=0){
?>

<table border="1" align="center">
    <form action="search.php" method="get">
        <tr>
            <td colspan="2">Company Logo</td>
            <td colspan="2" align="right"><input type="text" name='search' placeholder="Search by name.."></td>
            <td colspan="2" align="center"><input type="submit"></td>
        </tr>
    </form>
    
    <tr>
        <th>Roll No.</th>
        <th>Image</th>
        <th>Name</th>
        <th>Course</th>
        <th colspan="2">Action</th>
    </tr>
    
<?php
    while($result=mysqli_fetch_assoc($data)){

       echo "
       <tr>
            <td> ".$result['roll']."</td>
            <td><img src='$result[imglink]' height='50' width='50'></td>
            <td> ".$result['name']."</td>
            <td> ".$result['course']."</td>
            <td><a href='update.php?id=$result[id]&roll=$result[roll]&image=$result[imglink]&name=$result[name]&course=$result[course]'><img src='images/edit.png' width='20' height='20 '></a></td>
            <td><a href='delete.php?id=$result[id]' onclick='return checkdelete()'><img src='images/delete.png' width='20' height='20'></a></td>
       </tr>";
    // echo $result['roll']." ".$result['name']." ".$result['course']. "<br>";
    }
}
else{
    echo "No record found";
}

$query2= "SELECT * FROM stu_details";
$data1=mysqli_query($conn, $query2) or die("Query Failed");


if(mysqli_num_rows($data1)>0){
    $total_records=mysqli_num_rows($data);
    $total_page= ceil($total_records/$limit);

    echo "<tr>";
    echo "<td colspan='6'><ul>";
    for($i=1; $i<= $total_page; $i++){
        if($i==$page){
            $active="active";
        }
        else{
            $active="";
        }
        echo '<li class="'.$active.'"><a href="fetch.php?page='.$i.'">'.$i.'</li>';
    }
    echo "</td></ul>";
    echo "</tr>";
}

?>
</table>	

<br>
<a href="logout.php">Logout</a>

<script>
    function checkdelete(){
       return confirm('Are you sure you want to delete..??');
    }
</script>
