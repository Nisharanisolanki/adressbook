<?php
include("connection.php");
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
</head>
<?php

echo "<h3 align='right' style='background-color:black; color:white; display: inline; padding: 5px;'>"."Welcome ". $_SESSION['user_name']."</h3><br>";
$userprofile=$_SESSION['user_name'];

if($userprofile==null){
    header('location:login.php');
}

// if($userprofile==true){

// }else{
//     header('location:login.php');

// }


if(isset($_POST['submit'])){

    $roll=$_POST['rollno'];
    $name=$_POST['name'];
    $course=$_POST['course'];

    $filename=$_FILES['image']['name'];
    $tempname=$_FILES['image']['tmp_name'];

    // $fileExt= explode('.', $filename);
    // $fileExtCheck= strtolower(end($fileExt));
    // echo $fileExtCheck;

    // $vaildFileExt=array('png', 'jpg', 'jpeg');

    // if(in_array($fileExtCheck, $vaildFileExt)){
    //     // Write to Image Upload Code Here
    // }else{
    //     echo "<script>alert('Please Upload a valid File');</script>";
    // }

    $folder="Images/".$filename;
    move_uploaded_file($tempname, $folder);

    if($roll!="" && $name!="" && $course!=""){
        $query="INSERT INTO stu_details VALUES (null, '$roll', '$folder', '$name', '$course', '$userprofile', '')";
        $data=mysqli_query($conn, $query);

        if($data){
            echo "<script>alert('Data entered Succesfully')</script>";
        }
        else{
            echo "<script>alert('Failed to insert Data')</script>";
        }
    }else{
        echo "<font color='red' size='5'>All fields are required </font>";
    }
}
?>
<body>
    <form action="" method="post" enctype="multipart/form-data">
        <table border="0" align="center">
            <tr>
                <th colspan="2">Enter Details </th>
            </tr>
            <tr>
                <td>Roll</td>
                <td><input type="text" name="rollno"></td>
            </tr>
            <tr>
                <td>Name</td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <td>Course</td>
                <td><input type="text" name="course"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="file" name="image"></td>
            </tr>
            <tr>
                <td colspan="2" align="right"><input type="submit" name="submit"></td>
            </tr>
        </table>

    </form>
</body>
</html>