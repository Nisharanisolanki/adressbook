<?php
session_start();
    include("connection.php");

    if(isset($_POST['submit'])){
        $user=$_POST['username'];
        $pwd=$_POST['password'];
        $query="SELECT * FROM stu_details WHERE username='$user' AND password='$pwd'";
        $data=mysqli_query($conn,$query);
		
        $records=mysqli_num_rows($data);

        if($records==1){
            $_SESSION['user_name']=$user;
            header('location:insert.php');
        }
        else{
            echo "<script>alert('Login Failed')</script>";
        }
    }
?> 
<form action="" method="post">
<table border="1" align="center">
    <tr>
        <td>Username</td>
        <td><input type="text" name="username"></td>
    </tr>
    <tr>
        <td>Password</td>
        <td><input type="text" name="password"></td>
    </tr>
    <tr>
       <td colspan="3" align="right"><input type="submit" name="submit" value="submit"></td>
    </tr> 
</table>
</form>
