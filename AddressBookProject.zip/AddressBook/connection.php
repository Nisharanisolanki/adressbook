<?php
    $servername="localhost";
    $username="root";
    $password="";
    $dbname="students";

    $conn=mysqli_connect($servername,$username,$password,$dbname);

    if($conn){
        echo "";
    }
    else{
       die("Connection not Established". mysqli_connect_error());
    }
?>