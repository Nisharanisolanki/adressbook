<?php
session_start();

include('connection.php');
$id=$_GET['id'];

$query="DELETE FROM stu_details WHERE id='$id'";
$data=mysqli_query($conn, $query);

if($data):
    echo "Record Deleted form table";
?>

<meta http-equiv="refresh" content="0; url='fetch.php'">

<?php
else:
    echo "Failed to delete record from table";
endif;
?>

</body>
</html>