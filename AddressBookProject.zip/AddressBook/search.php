<style>
    td{
        padding: 5px;
    }
</style>

<?php
include("connection.php");
session_start();

$userprofile=$_SESSION['user_name'];

if($userprofile==null){
    header('location:login.php');
}



$search=$_GET['search'];
$s_query="SELECT * FROM stu_details WHERE name='$search'";
$s_data= mysqli_query($conn, $s_query);
$total= mysqli_num_rows($s_data);

if($total!=0){
?>

<table border="1" align="center">
    <form action="search.php" method="get">
        <tr>
            <td colspan="2">Company Logo</td>
            <td colspan="2" align="right"><input type="text" name='search' placeholder="Search by name.."></td>
            <td colspan="2" align="center"><input type="submit"></td>
        </tr>
    </form>
    
    <tr>
        <th>Roll No.</th>
        <th>Image</th>
        <th>Name</th>
        <th>Course</th>
        <th colspan="2">Action</th>
    </tr>
    
<?php

    while($result=mysqli_fetch_assoc($s_data)){
       
       echo "
       <tr>
            <td> ".$result['roll']."</td>
            <td><img src='$result[imglink]' height='50' width='50'></td>
            <td> ".$result['name']."</td>
            <td> ".$result['course']."</td>
            <td><a href='update.php?roll=$result[roll]&image=$result[imglink]&name=$result[name]&course=$result[course]'>Edit</a></td>
            <td><a href='delete.php?roll=$result[roll]' onclick='return checkdelete()'>Delete</a></td>
       </tr>";
    // echo $result['roll']." ".$result['name']." ".$result['course']. "<br>";
    }
}
else{
    echo "<font color='red' size='5'>Sorry... :( No record found..!!</font>";
}
?>
</table>

<script>
    function checkdelete(){
       return confirm('Are you sure you want to delete..??');
    }
</script>
